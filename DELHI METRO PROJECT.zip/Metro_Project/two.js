setTimeout(function(){
    window.location.href='four.html';},5000
);

