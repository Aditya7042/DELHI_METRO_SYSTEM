setTimeout(function(){
    window.location.href='two.html';},5000
);